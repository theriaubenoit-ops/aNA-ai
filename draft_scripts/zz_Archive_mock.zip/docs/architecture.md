## **Architecture**

### **Level 1: Core Brain Simulation**
```
aNA v5.0 Autonomous Neural Architecture
├── Main Controller (Brainv5)
├── 3D Visualization Engine
└── Event Management System
```

### **Level 2: Primary Brain Structures**
```
├── Cerebral Cortex (The "Thinking" Shell, 4 Lobes + 6 Layers)
│   ├── Frontal Lobe (Logic, Planning, Motor)
│   │   ├── Prefrontal Cortex (Executive Function)
│   │   ├── Motor Cortex (Movement Planning)
│   │   └── Broca's Area (Speech Production)
│   │
│   ├── Parietal Lobe (Integration, Spatial)
│   │   ├── Somatosensory Cortex (Touch Processing)
│   │   ├── Spatial Processing (Navigation)
│   │   └── Multisensory Integration
│   │
│   ├── Temporal Lobe (Memory, Auditory)
│   │   ├── Auditory Cortex (Sound Processing)
│   │   ├── Wernicke's Area (Language Comprehension)
│   │   └── Memory Formation (with Hippocampus)
│   │
│   ├── Occipital Lobe (Vision)
│   │   ├── Primary Visual Cortex (V1)
│   │   ├── Visual Association Areas (V2-V5)
│   │   └── Object Recognition
│   │
│   ├── Internal Wiring: Lobe-specific 6-layer columns
│   └── Long-range Wiring (The "Bridges"):
│       ├── Arcuate Fasciculus (Temporal <-> Frontal): Language/Logic Loop
│       └── Superior Longitudinal Fasciculus (Parietal <-> Frontal): Spatial/Action Loop
│       └── # Corpus Callosum (NEW - Future: Left <-> Right Hemisphere)
│
├── Thalamus (The "Router", Sensory Gateway)
│   ├── Sensory Filtering, Relay Nuclei
│   │   ├── LGN (Visual → Occipital)
│   │   ├── MGN (Auditory → Temporal)
│   │   ├── VPL/VPM (Somatosensory → Parietal)
│   │   └── RTN (NEW - Firewall): Gain control and global inhibition
│   │
│   ├── Gating mechanism, Reticular Thalamic Nucleus (RTN) : Inhibits signal if global charge is too high
│   └── Thalamocortical Loops: Maintains the "Awake" state frequency
│
├── Hippocampus (The "Buffer", Memory System)
│   ├── Dentate Gyrus/CA4 (Pattern Separation: Prevents memory overlap)
│   ├── CA3 (Autoassociative Memory)
│   ├── CA2 (Social and temporal relay. It is a buffer between CA3 and CA1)
│   ├── CA1 (Pattern Integration, final output)
│   └── Entorhinal Cortex (The bidirectional bridge to the Cortex)
│
├── Cerebellum (NEW - The "Clock", Timing & Error Correction)
│   └── Coordination between Motor Cortex and Sensory Feedback
│
└── Amygdala (NEW - The "Priority Filter", Emotional Valence)
    └── Labels incoming charges as "Important" or "Neutral"
```

### **Level 3: Cortical Layer Organization (in each Lobe)**
```
Cortical Layer Dynamics (Each Lobe contains 6 Cortical Layers)
├── Layer I: Molecular (Context & Feedback Integration from other Lobes)
├── Layer II/III: External (Inter-lobar Bridges - Arcuate/Longitudinal)
├── Layer IV: Internal Granular (Sensory Gateway - LGN/MGN reception)
├── Layer V: Internal Pyramidal (Motor Output - Cerebellum/Subcortical)
└── Layer VI: Multiform (Thalamic Regulatory Loop - Gain Control)
```

### **Level 4: Lobe-Specific Functional Systems**
```
├── Frontal Lobe System
│   ├── Executive Function (Prefrontal)
│   ├── Motor Planning and Execution
│   ├── Decision Making
│   └── Working Memory
│
├── Parietal Lobe System
│   ├── Spatial Awareness and Navigation
│   ├── Sensory Integration
│   ├── Attention Control
│   └── Mathematical Processing
│
├── Temporal Lobe System
│   ├── Auditory Processing
│   ├── Language Comprehension
│   ├── Memory Encoding/Retrieval
│   └── Object Recognition
│
└── Occipital Lobe System
    ├── Visual Processing (Primary)
    ├── Visual Association (Secondary)
    ├── Motion Detection
    └── Color and Shape Recognition
```

### **Level 5: Cross-Lobe Integration**
```
├── Inter-lobar Communication
│   ├── Frontal-Pariental Network (Attention)
│   ├── Temporal-Occipital Network (Visual Memory)
│   ├── Frontal-Temporal Network (Language)
│   └── Parietal-Occipital Network (Spatial Vision)
│
├── Sensory-Motor Integration
│   ├── Occipital → Parietal → Frontal (Visual Guidance)
│   ├── Temporal → Frontal (Auditory Guidance)
│   └── Parietal → Frontal (Somatosensory Guidance)
│
└── Memory Networks
    ├── Hippocampus ↔ Temporal Lobe (Episodic Memory)
    ├── Hippocampus ↔ Frontal Lobe (Working Memory)
    └── Hippocampus ↔ Parietal Lobe (Spatial Memory)
```

### **Level 6: Dynamic Processing Flow**
```
Dynamic Processing Flow:
├── Ascending (Bottom-Up): Thalamus → Occipital → Parietal → Frontal. (I see, I locate, I decide)
├── Descending (Top-Down): Frontal → Thalamus. (I decide to stop listening to this noise; the Thalamus closes the door)

Sensory Input Pathways:
├── Visual: Thalamus (LGN) → Occipital Lobe → Temporal/Frontal
├── Auditory: Thalamus (MGN) → Temporal Lobe → Frontal
└── Somatosensory: Thalamus (VPL/VPM) → Parietal Lobe → Frontal

Processing Hierarchy:
├── Primary Sensory Areas (Layer IV) → Association Areas (Layers II/III)
├── Association Areas → Integration Centers (All Layers)
└── Integration Centers → Motor Planning (Frontal Layer V)
```

### **Level 7: Functional Specialization by Lobe (Role Summary)**
```
├── Occipital Lobe (Posterior “What” and “Where”)
│   - Primary: Visual Processing
│   - Secondary: Visual Association
│   - Tertiary: Visual Integration
│
├── Parietal Lobe (Superior “Where” and “How much” - logical)
│   - Primary: Somatosensory
│   - Secondary: Spatial Processing
│   - Tertiary: Multisensory Integration
│
├── Temporal Lobe (Inferior “Who” and “What” semantics - language/memory)
│   - Primary: Auditory Processing
│   - Secondary: Language and Memory
│   - Tertiary: Object Recognition
│
└── Frontal Lobe (Anterior “How” and “When” - action/decision)
    - Primary: Motor Planning
    - Secondary: Executive Function
    - Tertiary: Decision Making
```

### **Level 8: Neuromodulator Matrix (The Chemical Layer):**
```
├── NO (Nitric Oxide) -> Volumetric Retrograde Signaling
│   └── Role: "Zone Strengthening". Diffuses from active neurons to nearby
│       synapses to signal "We just fired together, strengthen everything here."
│       (Crucial for local clusters and blood flow simulation).
│
├── Acetylcholine NEW -> Sensory Sensitivity (Layer IV)
│   └── Role: "Focus & Alertness". Lowers the firing threshold of Layer IV
│       to make external inputs (Thalamus) more prominent.
│
├── Dopamine -> Reward & Plasticity (Layers II/III)
│   └── Role: "Learning Signal". Acts as a multiplier for LTP (Long-Term
│       Potentiation) in the association layers. No Dopamine = No Memory growth.
│
├─── Serotonin NEW -> Homeostatic Balance (Global)
│   └── Role: "The Governor". Prevents runaway excitation (Epilepsy simulation)
│       by stabilizing the global neural threshold.
│
└─── Adrenaline NEW -> Hyper-Alertness & Flashbulb Memory
    ├── Sensitivity: Agit comme un multiplicateur de gain global.
    │   Toutes les couches (I à VI) deviennent extrêmement réactives.
    ├── Concentration: Réduit le "bruit" de fond en augmentant le
    │   contraste entre les neurones très actifs et les neurones au repos.
    └── Learning: Déclenche une "Capture de Mémoire" instantanée
        (Plus de charge envoyée vers l'Hippocampe/CA3).
```
